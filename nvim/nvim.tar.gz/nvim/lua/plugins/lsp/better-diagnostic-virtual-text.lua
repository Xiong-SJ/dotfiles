return {
	"sontungexpt/better-diagnostic-virtual-text",
	config = function()
		require("better-diagnostic-virtual-text").setup()
		-- 关闭内置 virtual_text，让插件接管
		vim.diagnostic.config({ virtual_text = false })

		local function toggle_diagnostics()
			local current_text = vim.diagnostic.config().virtual_text
			-- local current_lines = vim.diagnostic.config().virtual_lines
			vim.diagnostic.config({
				virtual_text = not current_text,
				-- virtual_lines = not current_lines,
			})
			-- 提示用户升级/检查版本
		end

		vim.keymap.set({ "n", "x" }, "<F3>", toggle_diagnostics, { desc = "Toggle diagnostic display" })
	end,
}
